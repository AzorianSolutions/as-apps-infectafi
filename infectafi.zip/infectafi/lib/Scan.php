<?php

class Scan
{

}