<?php

class Attack
{

}