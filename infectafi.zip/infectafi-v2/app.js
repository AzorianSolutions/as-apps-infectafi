const core = require('./lib/infectafi/core')
core.init();